package com.example.restaurante.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BebidaController {

    @GetMapping("/bebidas")
    public String listarBebidas() {
        return "Bebidas disponíveis: Refrigerante, Suco, Água";
    }
}