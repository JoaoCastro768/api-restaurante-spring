package com.example.restaurante.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PratoController {

    @GetMapping("/pratos")
    public String listarPratos() {
        return "Pratos disponíveis: Pizza, Hambúrguer, Lasanha";
    }

    @GetMapping("/pratos/destaque")
    public String pratoDestaque() {
        return "Prato destaque do dia: Pizza Margherita";
    }
}