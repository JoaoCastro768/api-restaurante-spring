package com.restaurante.api.controller;

import com.restaurante.api.model.Funcionario;
import com.restaurante.api.repository.FuncionarioRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/funcionarios")
@Tag(name = "Funcionarios", description = "Gerenciamento dos funcionarios do restaurante")
public class FuncionarioController {

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    @GetMapping
    @Operation(summary = "Listar todos os funcionarios", description = "Retorna todos os funcionarios cadastrados no banco de dados")
    public ResponseEntity<List<Funcionario>> findAll() {
        List<Funcionario> funcionarios = funcionarioRepository.findAll();
        return ResponseEntity.ok(funcionarios);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar funcionario por ID", description = "Retorna um funcionario especifico pelo seu ID")
    public ResponseEntity<Funcionario> findById(@PathVariable Long id) {
        Optional<Funcionario> funcionario = funcionarioRepository.findById(id);
        return funcionario.map(ResponseEntity::ok)
                          .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Criar novo funcionario", description = "Cadastra um novo funcionario no banco de dados")
    public ResponseEntity<Funcionario> create(@RequestBody Funcionario funcionario) {
        if (funcionario.getAtivo() == null) {
            funcionario.setAtivo(true);
        }
        Funcionario salvo = funcionarioRepository.save(funcionario);
        return ResponseEntity.status(HttpStatus.CREATED).body(salvo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualizar funcionario", description = "Atualiza os dados de um funcionario existente")
    public ResponseEntity<Funcionario> update(@PathVariable Long id, @RequestBody Funcionario funcionarioAtualizado) {
        if (!funcionarioRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        funcionarioAtualizado.setId(id);
        Funcionario atualizado = funcionarioRepository.save(funcionarioAtualizado);
        return ResponseEntity.ok(atualizado);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deletar funcionario", description = "Remove um funcionario do banco de dados")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!funcionarioRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        funcionarioRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
