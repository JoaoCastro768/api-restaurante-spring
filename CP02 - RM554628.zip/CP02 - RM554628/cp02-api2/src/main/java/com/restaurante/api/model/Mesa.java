package com.restaurante.api.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mesas")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Mesa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "numero", nullable = false, unique = true)
    private Integer numero;

    @Column(name = "capacidade", nullable = false)
    private Integer capacidade;

    @Column(name = "status", nullable = false, length = 30)
    private String status;

    @Column(name = "localizacao", nullable = false, length = 50)
    private String localizacao;

    @Column(name = "ativa", nullable = false)
    private Boolean ativa;

    @Column(name = "observacoes", nullable = true, length = 200)
    private String observacoes;

    @Column(name = "nome_cliente_atual", nullable = true, length = 100)
    private String nomeClienteAtual;
}
