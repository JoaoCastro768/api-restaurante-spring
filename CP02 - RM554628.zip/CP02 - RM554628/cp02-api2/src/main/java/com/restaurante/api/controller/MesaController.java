package com.restaurante.api.controller;

import com.restaurante.api.model.Mesa;
import com.restaurante.api.repository.MesaRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/mesas")
@Tag(name = "Mesas", description = "Gerenciamento das mesas do restaurante")
public class MesaController {

    @Autowired
    private MesaRepository mesaRepository;

    @GetMapping
    @Operation(summary = "Listar todas as mesas", description = "Retorna todas as mesas cadastradas no banco de dados")
    public ResponseEntity<List<Mesa>> findAll() {
        List<Mesa> mesas = mesaRepository.findAll();
        return ResponseEntity.ok(mesas);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar mesa por ID", description = "Retorna uma mesa especifica pelo seu ID")
    public ResponseEntity<Mesa> findById(@PathVariable Long id) {
        Optional<Mesa> mesa = mesaRepository.findById(id);
        return mesa.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Criar nova mesa", description = "Cadastra uma nova mesa no banco de dados")
    public ResponseEntity<Mesa> create(@RequestBody Mesa mesa) {
        if (mesa.getAtiva() == null) {
            mesa.setAtiva(true);
        }
        if (mesa.getStatus() == null || mesa.getStatus().isBlank()) {
            mesa.setStatus("LIVRE");
        }
        Mesa salva = mesaRepository.save(mesa);
        return ResponseEntity.status(HttpStatus.CREATED).body(salva);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualizar mesa", description = "Atualiza os dados de uma mesa existente")
    public ResponseEntity<Mesa> update(@PathVariable Long id, @RequestBody Mesa mesaAtualizada) {
        if (!mesaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        mesaAtualizada.setId(id);
        Mesa atualizada = mesaRepository.save(mesaAtualizada);
        return ResponseEntity.ok(atualizada);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deletar mesa", description = "Remove uma mesa do banco de dados")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!mesaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        mesaRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
