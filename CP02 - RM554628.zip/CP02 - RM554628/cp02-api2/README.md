# 🍽️ API Restaurante — Gestão de Mesas e Funcionários | Checkpoint 2

API RESTful para gerenciamento de **mesas** e **funcionários** de um restaurante.  
Desenvolvida com **Spring Boot 3**, **Spring Data JPA** e **MySQL**.

---

## 🗂️ Entidades e Tabelas

### `Mesa` → tabela `mesas`

| Campo | Tipo | Nullable |
|---|---|---|
| id | Long (PK) | NÃO |
| numero | Integer | NÃO |
| capacidade | Integer | NÃO |
| status | String | NÃO |
| localizacao | String | NÃO |
| ativa | Boolean | NÃO |
| observacoes | String | **SIM** |
| nomeClienteAtual | String | **SIM** |

### `Funcionario` → tabela `funcionarios`

| Campo | Tipo | Nullable |
|---|---|---|
| id | Long (PK) | NÃO |
| nome | String | NÃO |
| cargo | String | NÃO |
| salario | BigDecimal | NÃO |
| dataAdmissao | LocalDate | NÃO |
| ativo | Boolean | NÃO |
| telefone | String | **SIM** |
| email | String | **SIM** |

---

## 🚀 Como Rodar a Aplicação

### Pré-requisitos
- Java 17+
- Maven 3.8+
- Docker e Docker Compose instalados

---

### 1️⃣ Subir o Banco de Dados com Docker

Na raiz do projeto, execute o comando:

```bash
docker compose up -d
```

Se seu Docker usar o comando antigo, utilize:

```bash
docker-compose up -d
```

Isso irá subir um container MySQL com as seguintes configurações:

| Parâmetro | Valor |
|---|---|
| Host | localhost |
| Porta | 3306 |
| Usuário | root |
| Senha | root123 |
| Banco | restaurante_gestao_db |

Para verificar se o container está rodando:
```bash
docker ps
```

Para parar o container:
```bash
docker compose down
```

Ou, no comando antigo:

```bash
docker-compose down
```

---

### 2️⃣ Rodar a Aplicação

```bash
mvn spring-boot:run
```

A aplicação estará disponível em: **http://localhost:8080**

---

## 📖 Documentação Swagger

Acesse a documentação interativa da API:

```
http://localhost:8080/swagger-ui.html
```

---

## 🔗 Endpoints Disponíveis

### Mesas — `/mesas`

| Método | Rota | Ação |
|--------|------|------|
| `GET` | `/mesas` | Listar todas as mesas |
| `GET` | `/mesas/{id}` | Buscar mesa por ID |
| `POST` | `/mesas` | Criar nova mesa |
| `PUT` | `/mesas/{id}` | Atualizar mesa |
| `DELETE` | `/mesas/{id}` | Deletar mesa |

### Funcionários — `/funcionarios`

| Método | Rota | Ação |
|--------|------|------|
| `GET` | `/funcionarios` | Listar todos os funcionários |
| `GET` | `/funcionarios/{id}` | Buscar funcionário por ID |
| `POST` | `/funcionarios` | Criar novo funcionário |
| `PUT` | `/funcionarios/{id}` | Atualizar funcionário |
| `DELETE` | `/funcionarios/{id}` | Deletar funcionário |

---

## 📦 Exemplos de Requisição

### POST `/mesas`
```json
{
  "numero": 1,
  "capacidade": 4,
  "status": "LIVRE",
  "localizacao": "Salao",
  "ativa": true,
  "observacoes": "Mesa proxima a janela",
  "nomeClienteAtual": null
}
```

### POST `/funcionarios`
```json
{
  "nome": "Carlos Oliveira",
  "cargo": "Garcom",
  "salario": 2200.00,
  "dataAdmissao": "2024-03-15",
  "ativo": true,
  "telefone": "11999990000",
  "email": "carlos@restaurante.com"
}
```

---

## ✅ Checklist do Checkpoint 2

- [x] 2 entidades no singular com tabelas no plural usando `@Table`
- [x] Pelo menos 5 atributos em cada entidade
- [x] Pelo menos 1 campo `nullable = true` em cada entidade, sem contar o ID
- [x] Repositories com `JpaRepository`
- [x] CRUD completo nas Controllers
- [x] `findAll` e `findById` usando `GET`
- [x] Conexão com MySQL via Spring Data JPA
- [x] Porta obrigatória `8080`
- [x] Docker documentado para subir o banco
- [x] Swagger/OpenAPI ativo

---

## 🧪 Teste rápido com cURL

Criar uma mesa:

```bash
curl -X POST http://localhost:8080/mesas \
  -H "Content-Type: application/json" \
  -d '{"numero":1,"capacidade":4,"status":"LIVRE","localizacao":"Salao","ativa":true,"observacoes":"Mesa próxima à janela","nomeClienteAtual":null}'
```

Listar mesas:

```bash
curl http://localhost:8080/mesas
```

Criar um funcionário:

```bash
curl -X POST http://localhost:8080/funcionarios \
  -H "Content-Type: application/json" \
  -d '{"nome":"Carlos Oliveira","cargo":"Garcom","salario":2200.00,"dataAdmissao":"2024-03-15","ativo":true,"telefone":"11999990000","email":"carlos@restaurante.com"}'
```

---

## ⚠️ Observação importante

Como a exigência do checkpoint pede a porta `8080`, rode uma API por vez se estiver testando os dois projetos na mesma máquina.
