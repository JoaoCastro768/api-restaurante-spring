# 🍽️ API Restaurante — Cardápio e Pedidos | Checkpoint 2

API RESTful para gerenciamento de **pratos** e **pedidos** de um restaurante.  
Desenvolvida com **Spring Boot 3**, **Spring Data JPA** e **MySQL**.

---

## 🗂️ Entidades e Tabelas

### `Prato` → tabela `pratos`

| Campo | Tipo | Nullable |
|---|---|---|
| id | Long (PK) | NÃO |
| nome | String | NÃO |
| preco | BigDecimal | NÃO |
| categoria | String | NÃO |
| disponivel | Boolean | NÃO |
| tempoPreparoMinutos | Integer | NÃO |
| descricao | String | **SIM** |
| calorias | Integer | **SIM** |

### `Pedido` → tabela `pedidos`

| Campo | Tipo | Nullable |
|---|---|---|
| id | Long (PK) | NÃO |
| numeroMesa | Integer | NÃO |
| nomeCliente | String | NÃO |
| status | String | NÃO |
| valorTotal | BigDecimal | NÃO |
| dataPedido | LocalDateTime | NÃO |
| observacoes | String | **SIM** |
| formaPagamento | String | **SIM** |

---

## 🚀 Como Rodar a Aplicação

### Pré-requisitos
- Java 17+
- Maven 3.8+
- Docker e Docker Compose instalados

---

### 1️⃣ Subir o Banco de Dados com Docker

Na raiz do projeto, execute o comando:

```bash
docker compose up -d
```

Se seu Docker usar o comando antigo, utilize:

```bash
docker-compose up -d
```

Isso irá subir um container MySQL com as seguintes configurações:

| Parâmetro | Valor |
|---|---|
| Host | localhost |
| Porta | 3306 |
| Usuário | root |
| Senha | root123 |
| Banco | restaurante_cardapio_db |

Para verificar se o container está rodando:
```bash
docker ps
```

Para parar o container:
```bash
docker compose down
```

Ou, no comando antigo:

```bash
docker-compose down
```

---

### 2️⃣ Rodar a Aplicação

```bash
mvn spring-boot:run
```

A aplicação estará disponível em: **http://localhost:8080**

---

## 📖 Documentação Swagger

Acesse a documentação interativa da API:

```
http://localhost:8080/swagger-ui.html
```

---

## 🔗 Endpoints Disponíveis

### Pratos — `/pratos`

| Método | Rota | Ação |
|--------|------|------|
| `GET` | `/pratos` | Listar todos os pratos |
| `GET` | `/pratos/{id}` | Buscar prato por ID |
| `POST` | `/pratos` | Criar novo prato |
| `PUT` | `/pratos/{id}` | Atualizar prato |
| `DELETE` | `/pratos/{id}` | Deletar prato |

### Pedidos — `/pedidos`

| Método | Rota | Ação |
|--------|------|------|
| `GET` | `/pedidos` | Listar todos os pedidos |
| `GET` | `/pedidos/{id}` | Buscar pedido por ID |
| `POST` | `/pedidos` | Criar novo pedido |
| `PUT` | `/pedidos/{id}` | Atualizar pedido |
| `DELETE` | `/pedidos/{id}` | Deletar pedido |

---

## 📦 Exemplos de Requisição

### POST `/pratos`
```json
{
  "nome": "Frango Grelhado",
  "preco": 35.90,
  "categoria": "Prato Principal",
  "disponivel": true,
  "tempoPreparoMinutos": 25,
  "descricao": "Frango grelhado com legumes e arroz",
  "calorias": 450
}
```

### POST `/pedidos`
```json
{
  "numeroMesa": 5,
  "nomeCliente": "João Silva",
  "status": "PENDENTE",
  "valorTotal": 71.80,
  "dataPedido": "2026-05-04T19:30:00",
  "observacoes": "Sem cebola no prato",
  "formaPagamento": "Cartão de Crédito"
}
```

---

## ✅ Checklist do Checkpoint 2

- [x] 2 entidades no singular com tabelas no plural usando `@Table`
- [x] Pelo menos 5 atributos em cada entidade
- [x] Pelo menos 1 campo `nullable = true` em cada entidade, sem contar o ID
- [x] Repositories com `JpaRepository`
- [x] CRUD completo nas Controllers
- [x] `findAll` e `findById` usando `GET`
- [x] Conexão com MySQL via Spring Data JPA
- [x] Porta obrigatória `8080`
- [x] Docker documentado para subir o banco
- [x] Swagger/OpenAPI ativo

---

## 🧪 Teste rápido com cURL

Criar um prato:

```bash
curl -X POST http://localhost:8080/pratos \
  -H "Content-Type: application/json" \
  -d '{"nome":"Frango Grelhado","preco":35.90,"categoria":"Prato Principal","disponivel":true,"tempoPreparoMinutos":25,"descricao":"Frango grelhado com legumes","calorias":450}'
```

Listar pratos:

```bash
curl http://localhost:8080/pratos
```

Criar um pedido:

```bash
curl -X POST http://localhost:8080/pedidos \
  -H "Content-Type: application/json" \
  -d '{"numeroMesa":5,"nomeCliente":"João Silva","status":"PENDENTE","valorTotal":71.80,"observacoes":"Sem cebola","formaPagamento":"Cartão"}'
```

---

## ⚠️ Observação importante

Como a exigência do checkpoint pede a porta `8080`, rode uma API por vez se estiver testando os dois projetos na mesma máquina.
