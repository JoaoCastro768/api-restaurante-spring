package com.restaurante.api.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Entity
@Table(name = "pratos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Prato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "nome", nullable = false, length = 100)
    private String nome;

    @Column(name = "preco", nullable = false, precision = 10, scale = 2)
    private BigDecimal preco;

    @Column(name = "categoria", nullable = false, length = 50)
    private String categoria;

    @Column(name = "disponivel", nullable = false)
    private Boolean disponivel;

    @Column(name = "tempo_preparo_minutos", nullable = false)
    private Integer tempoPreparoMinutos;

    @Column(name = "descricao", nullable = true, length = 300)
    private String descricao;

    @Column(name = "calorias", nullable = true)
    private Integer calorias;
}
