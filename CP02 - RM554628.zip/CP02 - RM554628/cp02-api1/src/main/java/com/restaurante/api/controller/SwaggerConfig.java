package com.restaurante.api.controller;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API Restaurante - Cardapio e Pedidos | CP2")
                        .description("API RESTful para gerenciamento de pratos e pedidos do restaurante. " +
                                     "Desenvolvida com Spring Boot 3, Spring Data JPA e MySQL.")
                        .version("2.0.0"));
    }
}
