package com.restaurante.api.controller;

import com.restaurante.api.model.Prato;
import com.restaurante.api.repository.PratoRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/pratos")
@Tag(name = "Pratos", description = "Gerenciamento dos pratos do cardapio")
public class PratoController {

    @Autowired
    private PratoRepository pratoRepository;

    @GetMapping
    @Operation(summary = "Listar todos os pratos", description = "Retorna todos os pratos cadastrados no banco de dados")
    public ResponseEntity<List<Prato>> findAll() {
        List<Prato> pratos = pratoRepository.findAll();
        return ResponseEntity.ok(pratos);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar prato por ID", description = "Retorna um prato especifico pelo seu ID")
    public ResponseEntity<Prato> findById(@PathVariable Long id) {
        Optional<Prato> prato = pratoRepository.findById(id);
        return prato.map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Criar novo prato", description = "Cadastra um novo prato no banco de dados")
    public ResponseEntity<Prato> create(@RequestBody Prato prato) {
        Prato salvo = pratoRepository.save(prato);
        return ResponseEntity.status(HttpStatus.CREATED).body(salvo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualizar prato", description = "Atualiza os dados de um prato existente")
    public ResponseEntity<Prato> update(@PathVariable Long id, @RequestBody Prato pratoAtualizado) {
        if (!pratoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pratoAtualizado.setId(id);
        Prato atualizado = pratoRepository.save(pratoAtualizado);
        return ResponseEntity.ok(atualizado);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deletar prato", description = "Remove um prato do banco de dados")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!pratoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pratoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
