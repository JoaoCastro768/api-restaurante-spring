package com.restaurante.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestauranteCardapioApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestauranteCardapioApplication.class, args);
    }
}
